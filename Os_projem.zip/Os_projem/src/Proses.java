class Proses {
    int id;
    int variszamani;
    int oncelik;
    int proseszamani;
    int mbayt;            // Yeni eklenen özellik
    int yazicilar;        // Yeni eklenen özellik
    int tarayicilar;      // Yeni eklenen özellik
    int modemler;         // Yeni eklenen özellik
    int cdler;            // Yeni eklenen özellik

    // Proses sınıfı için constructor
    public Proses(int id, int variszamani, int oncelik, int proseszamani, int mbayt, int yazicilar, int tarayicilar, int modemler, int cdler) {
        this.id = id;
        this.variszamani = variszamani;
        this.oncelik = oncelik;
        this.proseszamani = proseszamani;
        this.mbayt = mbayt;
        this.yazicilar = yazicilar;
        this.tarayicilar = tarayicilar;
        this.modemler = modemler;
        this.cdler = cdler;
    }
}
